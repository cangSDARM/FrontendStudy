import event from './event.js';
import render from './render.js';

// 没有验证码部分

const defaultOpt = {
	container: document.getElementById("login-wrapper"),
	account: {
		label: "用户名",
		placeholder: "please input your name"
	},
	password: {
		label: "密码",
		placeholder: "please input your password"
	},
	submit: {
		prompt: "login"
	},
	autocomplete: true,
	success: (data)=>{},
	error: (data)=>{}
}

const login = (opts = {}) => {
	const option = Object.assign(defaultOpt, opts);	//merge
	render(option);
	event(option);

}


export { login }
