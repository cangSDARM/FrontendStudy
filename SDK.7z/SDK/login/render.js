import { sets } from './index.js';
import { getEleById } from '../commen/utils.js';

const template = (opts={}) => {
	const autocompletetpl = `<div id="no-autocomplete">
		<input type="text" />
		<input type="password" />
	</div>`;

	const autocompleteSwitch = opts.autocomplete ? 'on' : 'off';

	const tpl = `<form id="login-form" onsubmit="return false">
		${ opts.autocomplete && autocompletetpl }
		<label class="login-account-wrapper">
			<span class="account-label">${ opts.account.label }</span>
			<input id="login-account"
				name="account" type="text"
				placeholder="${ opts.account.placeholder }"
				autocomplete="${ autocompleteSwitch }"
				data-valid="present"
			/>
			<span id="clear-account" class="login-del">
		</label>

		<label class="login-password-wrapper">
			<span class="password-label">${ opts.password.label }</span>
			<input id="login-password"
				name="password" type="password"
				placeholder="${ opts.password.placeholder }"
				autocomplete="${ autocompleteSwitch }"
				data-valid="present"
			/>
		</label>

		<label id="login-verify-wrapper"></label>

		<input id="login-submit" class="login-submit" type="submit" value="${ opts.submit.prompt }"/>
	</form>`;

	return tpl.trim();
}

const noAutocompleteSet = ()=>{
	const nac = getEleById("no-autocomplete");
	if(nac){
		nac.style.opacity = "0";
		nac.style.height = "0";
	}
}

export default (opts={}) => {
	opts.container.innerHTML = template(opts);

	noAutocompleteSet();

}
