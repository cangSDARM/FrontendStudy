import { getElementById, check } from '../commen/utils.js';
import { post } from '../commen/fetch.js';
import Slider from '../commen/slider.js';

export default (opts={}) => {
	const form = getElementById("login-form");
	const btn = getElementById("login-submit");
	const clearA = getElementById("clear-account");
	const loginA = getElementById("login-account");
	const loginP = getElementById("login-password");
	const loginVW = getElementById("login-verify-wrapper");

	const slider = new Slider({
		container: loginVW,
		success: async (wrapper, offset) => {
			const data = await post('/verify', {
				...
			});

			if(data.code === 200){
				cookie.set('VerifyTOKEN', data.verify_token);
			}
		}
	})

	form.onsubmit = async (e) => {
		e.preventDefault();

		const checkR = check(form);
		!checkR.length && return;

		const data = await post('/login', {
			account: loginA.value,
			password: loginP.value,
		});

		if(data.code == 200){
			opts.success && opts.success(data);
		}else{
			opts.error && opts.error(data);
		}
	}

	loginA.oninput = () => {
		if(loginA.value.length){
			clearA.style.display = 'inline-block';
		}
		clearA.style.display = 'none';
	}
	loginP.oninput = () => {}
	clearA.onclick = (e) => {
		loginA.value = '';
		clearA.style.display = 'none';
	}
}
