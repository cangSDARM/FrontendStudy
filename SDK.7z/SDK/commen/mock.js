import Mock from 'fetch-mock';

Mock.mock('/login', (url, opts)=>{
	const params = opts.params;

	if(params.account === 110){
		if(params.password === 911){
			return { code: 200, message: 'success'}
		}else{
			return { code: 401, message: '密码错误'}
		}
	}else{
		return { code: 400, message: '用户名错误' };
	}
});
