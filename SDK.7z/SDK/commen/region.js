import { post } from './fetch.js';
import { getElementById } from './utils.js';

const render = Symbol('render');

class Region {
	constructor(opts){
		if(!opts.container){
			throw new Error('no container');
		}else{
			this[render](opts);
		}
	}

	async [render] = ( opts )=>{
		let regionData = await fetch('/region', {});

		const tpl = `<div id="region-wrapper">
			<select id="region-province"></select>
			<select id="region-city"></select>
			<select id="region-area"></select>
			<input id="region-selected" type="hidden" name="${ opts.name }" valid="present"/>
		</div>`

		opts.container.innerHTML = tpl;

		const province = getElementById('region-province');
		const city = getElementById('region-city');
		const area = getElementById('region-area');
		const selected = getElementById('region-selected');

		const provinceSd, citySd, areaSd;

		let provinceOp = `<option></option>`;
		for(let item of regionData){
			provinceOp += `<option value="${ item.id }">${ item.name }</option>`
		}

		province.innerHTML = provinceOp;
		city.onchange = () => {
			let areas = regionData[provinceSd - 1].city.filter((item)=>{
				return item.id === praseInt(city.value);
			})[0].areas;
			for (let item of areas){ /**/ }
		};

	}
}
