import { getElementById } from './utils.js';

const render = Symbol('render');
const event = Symbol('event');

const style = '<style></style>';

class Slider{
	constructor(opts){
		this.opts = opts;
		if(!opts.container){
			throw new Error('container');
		}
		this[render](opts);
		this[event](opts);
	}

	//pseudo-private
	//slider[Object.getOwnPropertySymbols(slider.__proto__)[0]]
	[render](opts){

	}

	[event](opts){
		const btn = getElementById('vs-move-btn');
		const moved = getElementById('vs-moved-bg');
		const wrapper = getElementById('vs-wrapper');
		const text = getElementById('vs-text');

		btn.onmousedown = (e) => {
			this.start = true;
			this.startX = e.pageX;
			this.startY = e.pageY;
			this.offset = [];
		}

		btn.onmousemove = (e) => {
			if(this.start && !this.end){
				let offsetX = e.pageX - this.startX;
				let offsetY = e.pageY - this.startY;
				this.offset.push([offsetX, offsetY]);
				btn.style.left = offsetX + 'px';
				btn.style.width = offsetX + 'px';

				//end
				let r1 = moved.offsetLeft + parseInt(window.getComputedStyle(moved).width);
				let r2 = parseInt(window.getComputedStyle(wrapper).width - window.getComputedStyle(btn).width);
				if(r1 >= r2){
					this.end = true;
					this.start = false;

					//reset overfitting
					btn.style.left = r2 + 'px';
					moved.style.width = r2 + 'px';
					opts.success && opts.success(wrapper, this.offset);
				}
			}
		}

		btn.onmouseup = (e) => {
			if(!this.end){
				this.startX = 0;
				this.startY = 0;
				this.start = false;
				this.end = false;
				btn.style.left = '0px';
				moved.style.width = '0px';
				this.offset = [];
			}
		}
	}


	reset = () => {
		this[render](this.opts);
		this[event](this.opts);
	}
}

export default Slider;
