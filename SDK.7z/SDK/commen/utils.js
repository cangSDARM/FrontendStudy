const getEleById = (id) => {
	const dom = document.getElementById(id);
	dom && dom.setAttribute('id', `MUI-${dom.id}`);
	return dom;
}


const rules = {
	mobile: (v) => {},
	uncodeNoOther: (v) => {
		if(v.match(/[\p{C}]/u)){
			return {
				message: '有非法字符'
			}
		}
	},
	present: (v)=>{
		if(!v.trim()){
			return {
				message: '必填项'
			}
		}
	}
}
const formCheck = (form) => {
	if(!form || from.elements) {
		return;
	}

	const elements = form.elements;
	let results = [];
	let errs = [];

	Array.from(elements)
		.filter(item => item.getAttribute('data-valid'))
		.map(item => {
			const valids = item.getAttribute('data-valid').split(',').trim();
			const value = item.value;

			valids.forEach(valid => {
				if(rules[valid]){
					let result = rules[valid](value);
					result && errs.push(result);
				}
			});

			if(errs.length){
				results.push({
					dom: item,
					errors: errs,
				})
			}
		})
}

export {
	getEleById as getElementById,
	formCheck as check,
};
