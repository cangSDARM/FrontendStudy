import React from 'react';
import {
	StyleSheet,
	Text,
	View,
	Image,
	TouchableOpacity,
} from 'react-native';

class TwoByThree extends React.Component{
	render(){
		return <View style={styles.container}>
			{this.props.Middle ?
				this.renderMiddle()
				: (this.props.BigLeft ? this.renderLeft() : this.renderRight()
					this.props.BigRight ? this.renderLeft() : this.renderRight())
			}
		</View>
	}
	leftData = {
		title: 'xxx',
		subtitle: 'xsad',
		disc: 'asea',
		price: 'saaa',
		icon: 'aseq'
	}
	renderLeft = ()=>{
		return <TouchableOpacity onPress={this.press}>
			<View>
				<Image source={{uri:this.leftData.title}} style={{
					width: '100%', height: '25%',
				}}/>
				<Image source={{uri:this.leftData.subtitle}} style={{
					width: '100%', height: '25%',
				}}/>
				<Text style={{
					width:'100%', height:'25%',
				}}>{this.leftData.disc}</Text>
				<View style={{
					width:'100%', height:'25%',
					justifyContent:'space-around', alignItems:'center'
				}}>
					<Text>{this.leftData.price}</Text>
					<Image source={{uri:this.leftData.icon}} style={{
						width: '25%', height:'100%'
					}}/>
				</View>
			</View>
		</TouchableOpacity>
	}
	rightData = [
		{
			title: 'xxx',
			subtitle: 'xxxx',
			color: '#334455',
			icon: 'xxss'
		},{
			title: 'xxx',
			subtitle: 'xxxx',
			color: '#334455',
			icon: 'xxss'
		}
	]
	renderRight = ()=>{
		return <View style={styles.rightwarpper}>
			{
				this.rightData.map((item, index)=>{
					<TouchableOpacity onPress={this.press}>
						<View style={styles.rightitem} key={index}>
							<View>
								<Text
									style={{
										color: item.color,
										fontWeight: 'blod',
										fontSize: 20
									}}
								>{item.title}</Text>
								<Text>{item.subtitle}</Text>
							</View>
							<Image source={item.icon} style={styles.img}/>
						</View>
					</TouchableOpacity>
				})
			}
		</View>
	}
	middleData = {
		title: 'asewq',
		color: '#556677',
		subtitle: 'aspeuqw',
		icon: 'qweyo'
	}
	renderMiddle = ()=>{
		return <TouchableOpacity onPress={this.press}>
			<View style={styles.middle}>
				<View style={{
					width: '50%', height: '100%',
					justifyContent: 'center', alignItems: 'center'
				}}>
					<Text style={{
						fontSize: 20, fontWeight: 'blod',
						color: this.middleData.color,
					}}>{this.middleData.title}</Text>
					<Text>{this.middleData.subtitle}</Text>
				</View>
				<Image source={{uri: this.middleData.icon}} style={{
					width: '50%',
					height: '100%'
				}}/>
			</View>
		</TouchableOpacity>
	}
	press = ()=>{
		alert('pressed');
	}
}

const styles = StyleSheet.create({
	container:{
		width: '100%',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		margin: '10 0 0 0',
	},
	rightwarpper: {
		width: '50%',
		height: '100%',
	},
	rightitem: {
		boxSizing: 'border-box',
		border: '1 solid gray',
		justifyContent: 'space-around',
		alignItems: 'center',
	},
	img: {
		width: '30%',
		height: '100%'
	},
	middle: {
		flexDirection: 'row',
		justifyContent: 'space-around',
		alignItems: 'center',
		width: '100%',
		padding: '0 5',
	}
});
export default TwoByThree;