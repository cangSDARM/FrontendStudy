import React from 'react';
import {
	StyleSheet,
	View,
	Text,
	ScrollView,
	TouchableOpacity
} from 'react-native';

import Nav from './nav';
import Top from './topnav';
import Layout from './layout';
import ShopCenter from './shopcenter';

class Main extends React.Component{

	render(){
		return <View style={styles.container}>
			<Nav />
			<ScrollView>
				<Top />
				<Layout BigLeft={true}/>
				<Layout Middle={true}/>
				<Layout />
			{/*这三个ShopCenter长的差不多，图片样式有些不同而已。懒得改了*/}
				<ShopCenter />
				<ShopCenter />
				<ShopCenter />
			</ScrollView>
		</View>
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
})

export default Main;