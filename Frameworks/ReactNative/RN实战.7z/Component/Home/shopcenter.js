import React from 'react';
import {
	StyleSheet,
	Text,
	View,
	Image
} from 'react-native';
import {Card, CardTitle, CardContent} from '@material-ui/core';

class Center extends React.Component{
	render(){
		return <View style={styles.container}>
			<Card>
				<CardTitle
					icon="shopcenter"
					title="sadsa"
				/>
				<CardContent>
					<View>
						<GridList
							row={3}
							colum={2}
							style={{margin:'5 0', width:'25%', height:'100%'}}
							data={{uri: 'xsda'}, {uri: 'xseq'}, {uri:'241'}}
							component={Image}
						/>
					</View>
				</CardContent>
			</Card>
		</View>
	}
}

const styles = StyleSheet.create({
	container:{
		margin: '10 0 0 0',
	},
});
export default Center;