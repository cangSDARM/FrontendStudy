import React from 'react';
import {
	StyleSheet,
	Text,
	View,
	Image,
	WebView,
} from 'react-native';

class Shop extends React.Component{
	state = {
		uri: 'https://www.baidu.com/',
		callback: function(){

		},
		detail: 'Shopping'
	}
	render(){
		return <View style={styles.container}>
			{this.renderNav()}
			<WebView
				automaticallyAdjustContentInsets={true}
				source={{uri: this.state.uri}}
				javaScriptEnabled={true}
				domStorageEnabled={true}
				decelerationRate="normal"
				startInLoadingState={true}
			/>
		</View>
	}
	renderNav = ()=>{
		return <View style={{
			width:'100%', height: 60,
			justifyContent: 'space-between', alignItems: 'center'
		}}>
			<TouchableOpacity onPress={this.press}>
				<Image source={{uri:'camera_back'}} style={{
					width: 20, height: '100%'
				}}/>
				<Text>{this.state.detail}</Text>
			</TouchableOpacity>
			<TouchableOpacity onPress={this.state.callback}>
				<Image source={{uri:'settings_circle'}} style={{
					width: 20, height: '100%'
				}}/>
			</TouchableOpacity>
		</View>
	}
	press = ()=>{
		alert('pressed');
	}
}

const styles = StyleSheet.create({
	container:{
		flex: 1
	},
	style
});
export default Shop;